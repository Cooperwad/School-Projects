package com.example.csc164finalprojectendlessrunner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class StartController {
    @FXML
    private Button quitButton;

    @FXML
    private Button startButton;

    @FXML
    void quitButtonEventHandler(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void startButtonEventHandler(ActionEvent event) {
        try {
            Stage gamePlayStage = (Stage) startButton.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("game-view.fxml"));
            Scene gameScene = new Scene(fxmlLoader.load(), 800, 600);
            gameScene.getRoot().requestFocus();
            gamePlayStage.setScene(gameScene);
            gamePlayStage.setTitle("Whoa game");
            gamePlayStage.show();
        } catch (IOException e){
            System.out.println("IOException Error. Whoops.");
        }
    }

//    public Stage getStartGame() {
//        //gamePlayStage.show();
//    }



    void initialize() {

    }
}