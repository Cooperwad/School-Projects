package com.example.csc164finalprojectendlessrunner;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;


public class GameController {

    private Stage gamePlayStage;

    private Stage pauseStage;

    private Scene gameScene;

    private StackPane pausePane = new StackPane(new Label("Pause Screen"));


    private boolean isPaused = false;

    public void startGame(Stage gamePlayStage) {


    }

//    @FXML
//    public void keyBoardInputEventHandler(KeyEvent event) {
//        if (event.getCode() == KeyCode.ESCAPE) {
//            if(isPaused) {
//                resumeGame();
//            }
//            else {
//                pauseGame();
//            }
//        }
//    }

//    public void pauseMenuStage() {
//        pauseStage = new Stage();
//        StackPane pausePane = new StackPane(new Label("Pause Screen"));
//        Scene pauseScene = new Scene(pausePane, 800, 600);
//        pauseStage.setScene(pauseScene);
//        pauseStage.show();
//    }


//    public void pauseGame() {
//        if (!isPaused) {
//            pauseStage = new Stage();
//            pauseMenuStage();
//            gamePlayStage.setScene(pauseStage.getScene());
//            isPaused = true;
//
//        }
//
//    }


//    public void resumeGame() {
//        gamePlayStage.setScene(gameScene);
//        pauseStage.hide();
//        isPaused = false;
//    }




}


