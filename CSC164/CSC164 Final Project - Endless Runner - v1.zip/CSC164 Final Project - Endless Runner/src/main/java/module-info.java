module com.example.csc164finalprojectendlessrunner {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.csc164finalprojectendlessrunner to javafx.fxml;
    exports com.example.csc164finalprojectendlessrunner;
}